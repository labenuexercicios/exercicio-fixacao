### Autobiografia -Isabelly Karen Souza Martins de Lima.

#### Nascida em 23/04/2000.

> Olá, me chamo Isabelly. Para os amigos apenas Isa. 

>Tenho 22 anos, moro em Natal/RN e sou bahiana de nascença. Sou cristã.

>Gosto muito de cantar e ouvir música, amo vôlei e board games. Mas ultimamente tenho tido um hobby que nunca imaginei hehehe, há uns meses passei a fazer pães caseiros e isso acabou se tornando algo que realmente gosto de fazer. 

>> Estudei Ciências Sociais na UFRN, não cheguei a concluir o curso, porém pretendo retornar algum dia, talvez na 3ª idade. Desde os 17 anos eu vinha trabalhando como auxiliar administrativa. Há um bom tempo tenho me interessado pela área de Programação, em abril desse ano, fiz um curso básico com carga horária de 80h, porém estudei várias horas à mais fora do horário do curso, para tentar adquirir mais conhecimento. Decidi então tentar essa transição de carreira, estou muito animada e feliz, pois pela primeira vez na vida, tenho gostado muito de estudar, é muito satisfatório ver algo que codei tomando forma, até o momento meu maior projeto foi um site bem básico sobre a Ada Lovelace. Estou amando o curso da Labenu. Espero concluí-lo com sucesso e trabalhar na área em um futuro próximo.